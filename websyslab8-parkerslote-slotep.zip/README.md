For the most part my code is pretty self explanatory.
I didn't add any css as it was unrequired, but if I
had more time I would add it. 

Other than that, it was a pretty fair quiz, but the
.htaccess part I thought was really bad, as we hadnt
touched it in class.