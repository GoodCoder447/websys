Alright lab, but the instructions are still really dated
like the last few labs haha. The doc didn't ask for us to 
do anything fancy with css, so all I did was just have 
a few seperater divs hidden and then show up on the click
of the #site img.