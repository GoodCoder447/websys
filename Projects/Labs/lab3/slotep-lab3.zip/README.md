Part 1: 
Little annoying, I ran into a bug where I had "onload = main", and then
in main I was changing the innerHTML of stuff so it was constantly 
running main. Got the my onload function from stack overflow

Part 2: 
This one was really easy, pretty much only had to add a few lines.

Part 3:
Not to bad, part of it was pretty annoying because I was using
"padding-left" instead of "paddingLeft". Overall wasn't too bad, 
found a pretty cool teal color.


