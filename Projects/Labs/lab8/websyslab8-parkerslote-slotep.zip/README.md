README.md

This lab was so bad. All we ended up doing was useless data entry. The lab itself took less than 15
minutes.